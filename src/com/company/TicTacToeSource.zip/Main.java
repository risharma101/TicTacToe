package com.company;

public class Main {

    public static void main(String[] args) {

        //creates new Game
        Game g = new Game();

    }
}
